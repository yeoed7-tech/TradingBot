6시간 Public WebSocket Paper 테스트 산출물 (2026-10-03 KST)

reports/phase45c2_20261003_retry01/: 최종 6시간 실행의 원시 로그, runtime 계측,
SQLite DB, 실행 결과, 독립 원장 대사, pytest 로그 및 session 산출물 전체.
docs/: C2 결과 보고서와 갱신된 진행/운영/설계 문서.
MANIFEST_SHA256.json: 포함된 원본 파일의 크기와 SHA-256.

먼저 docs/PHASE_4_5_C2_REPORT.md를 확인하세요.
6시간 2초 정상 종료, 표본 720개, 가상 주문/체결 2/2, 실주문 HTTP 0.
수수료 포함 실현손익 -91.38575694 KRW. 독립 Decimal 대사 및 SQLite 무결성 PASS.
전체 pytest: 124 passed, 2 failed (Windows에서 fork 미지원).
Windows 호환 회귀: 124 passed, 2 deselected. RSS 추세는 미계측.
이전 실패 재시도와 C1 원시 데이터는 이 ZIP에 포함하지 않았습니다.
