# 다음 단계 — Phase 4.5-C2 Operational Acceptance

**C1은 PASS / DONE이다.** 2026-09-30 새 단일 프로세스로 Paper 프로그램 3,600.276초, soak runner 3,602.007초를 연속 실행했다. 전체 회귀는 실행 전후 126개 통과했다. 자세한 증거와 범위는 `PHASE_4_5_C1_REPORT.md`에 있다.

다음 작업은 **Phase 4.5-C2 — 6-Hour Operational Acceptance**다. 별도 요청에서 새 DB와 같은 전략 설정으로 실행한다. 이번 작업에서는 C2, 24시간 soak, Phase 5를 시작하지 않았다.

| 남은 작업 | 상태 | 필요한 검증 |
|---|---|---|
| 6시간 Paper | NOT RUN | 새 DB에서 `scripts.soak_paper --hours 6`, 장기 RSS·DB·log 증가, 원장·reconciliation·audit 확인 |
| 24시간 Paper | NOT RUN | C2 이후 별도 요청과 새 DB 사용 |
| 작은 후반 RSS 증가의 장기 추세 | PARTIAL | 1시간 후반 slope 약 4.40 MB/h, 마지막 활성 약 8분은 약 1.51 MB/h. 초기화·종료와 구분해 6시간에서 추적 |
| PostgreSQL migration/Decimal/rollback/unique/fencing | ENVIRONMENT_LIMITATION | Docker/psql가 없는 현재 환경. 준비된 `docker-compose.postgres.yml`과 `scripts.verify_postgres`로 별도 검증 |
| malformed/backfill 독립 누적 계측 | PARTIAL | 현재 최종 JSON에 별도 카운터가 없음. 실제 HTTP는 adapter transport audit를 기준으로 확인 |
| Public WS 실연결 disconnect/reconnect/재시작 acceptance | PARTIAL | 이번 자연 운전은 reconnect/stale/gap 0. 모의 장애 회귀는 통과했지만 실제 장애 acceptance는 별도 수행 |
| 여러 호스트의 clock skew와 network partition | PARTIAL | 로컬 역행·도약/lease/fencing 시험 통과. 멀티호스트 조건은 검증 필요 |
| SQLite disk full/손상·백업 복원 | PARTIAL | 실제 write lock과 주입된 checkpoint 실패는 차단. 실제 디스크 장애·복원은 별도 시험 |
| 장기 retention/백업 정책 | PARTIAL | INFO event/중복 snapshot 수동 prune 구조 유지. 주문·체결·회계 원장·필수 recovery state는 보존 |
| 다종목 및 다수 active order | PARTIAL | 현재 BTC/KRW 한 종목. active order와 복구 캐시 상한 확장은 별도 정책 필요 |
| 외부 plugin의 전략 state snapshot | PARTIAL | 기본 EMA/RSI/Breakout 결정성은 검증됨. 임의 외부 상태 plugin은 별도 검증 |

Phase 4.5 전체는 운영·환경 gate가 남아 **PARTIAL**이다. Phase 5 private 인증·실제 balance/order/cancel 기능은 **NOT IMPLEMENTED**이며 자동으로 시작하지 않는다. 이전 환경 reset 시도는 `reports/phase45c1_attempts`에 보존했고 현재 C1 PASS와 합산하지 않았다.
