"""Read-only monitoring API."""
