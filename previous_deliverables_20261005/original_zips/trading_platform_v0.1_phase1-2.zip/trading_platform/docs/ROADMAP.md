# 단계별 다음 작업과 수용 기준

## 현재 체크포인트

Phase 1의 첫 E2E 완료 기준과 Phase 2의 기본 연구 기능을 구현했다.
운영 서비스 전체를 완료한 것은 아니다. 과거 데이터 기반 연구의 실행 결과를 기준으로 다음 단계를 진행한다.

## Phase 3 — 거래소 데이터 + 실제 시세 기반 Paper Trading

- ccxt async adapter 하나를 먼저 선택하고 ticker/OHLCV/order book/balance/positions/orders/fills/fees 계약에 연결.
- 거래소 선택 시 현물 종류, 주문 ID 지원, clientOrderId 중복 방지, 수수료 통화, 최소/정밀도 규칙을 실제 문서로 확인.
- 과거 데이터 pagination, rate limit/backoff, 중복 제거, 완료되지 않은 봉 제외, 재접속 후 gap backfill.
- 실시간/재생 Feed 공통 인터페이스로 BacktestEngine의 이벤트 조율부를 분리.
- SimulationBroker/ExecutionEngine을 재사용해 시세만 실제로 입력. 실제 주문 API는 paper 경로에서 접근 불가능하게 구성.
- 데이터 지연, 연결 끊김, 오래된 시세, 반복 오류에서 fail closed.
- 수용: mock stream 장애·복구, 연결 끊김·재시작 replay 테스트, 실제 공개 시세의 연속 관측, 실주문 호출 수 0.

## Phase 4 — 데이터베이스·재시작·모니터링

- SQLAlchemy 2.x ORM + Alembic; SQLite 개발, PostgreSQL 운영.
- 테이블: ohlcv(symbol,timeframe,timestamp unique), signals, orders(client_id unique), fills(exchange_fill_id unique),
  positions(account,symbol unique), portfolio_snapshots, strategy_runs, system_events, risk_state.
- 주문 의도를 DB transaction으로 먼저 기록하고 outbox로 제출. 응답 불명은 재주문 전에 거래소 조회.
- 체결 식별자로 원장 적용 exactly-once 효과를 만들고, DB 저장과 계좌 회계를 같은 transaction으로 반영.
- 재시작 때 리스크 kill 상태, 일/주 기준자산, peak, 미체결 주문, 마지막 시장 커서 복구.
- 실제 거래소 계좌와 DB 차이는 자동 신규 주문을 정지하고 reconciliation 처리.
- FastAPI 읽기 API + 간단한 UI: 총자산/현금/포지션/오늘·누적 손익/MDD/최근 주문/전략/연결/오류.
- 인증·네트워크 접근제어, 계정 비밀정보 redaction, 로그 회전.
- 수용: 체결 직전·직후 강제종료 후 복구, 중복 이벤트 replay에도 잔고 일치, SQLite/PostgreSQL 동일 회계 테스트.

## Phase 5 — 실거래 인프라 (자동 활성화 금지)

- 먼저 sandbox/testnet 지원 여부를 선택 거래소 문서로 확인하고 통합 테스트.
- 위험제어 보강: 실제 손절 주문/갭·실패 정책, 거래소 측 kill/cancel, 반복 API/주문 오류, 실제 슬리피지 감시.
- 통화·수수료·수량 Decimal 원장, dust 처리, 자산 환산, 부분체결·취소 경합·지연 응답 조정.
- LIVE_TRADING=false 기본값 + 별도 명시적 환경 스위치 + 승인된 strategy/config hash allowlist.
- AI가 생성한 후보는 research registry에만 저장; 사용자 승인 없는 live 활성화 또는 교체 금지.
- 전략 소스/파라미터/리스크 설정이 변경되면 승인 hash 무효화.
- 키는 secret manager 또는 로컬 비밀 환경에만 보관. 출금 권한 비활성화/허용 IP 등 거래소 지원 범위를 확인.
- 수용: 장애 주입 테스트, 독립 위험 한도, 재시작 reconciliation, 인증된 수동 kill, 명시적 사용자 승인 기록.
- 실제 자금 주문은 별도 사용자 지시와 확인된 거래소/계좌/한도 없이는 실행하지 않는다.

## 알려진 미구현/제한

- 실시간 Paper/Live, ORM/DB/복구, API/WebSocket retries, 거래소별 어댑터, FastAPI 대시보드.
- 거래당 확정 손절, Stop/Stop-limit/Take-profit, leverage/short/futures/funding, FX 환산.
- 봉 내부 체결 경로, 거래소 호가/큐 기반 체결, maker/taker 별도 수수료, 다른 통화로 지불하는 수수료.
- 거래소 정밀도 동적 조회, 상장/폐지 universe 수집, 주기별/거래소별 종목 변동.
- Bayesian 탐색, 통계적 다중검정 보정, 연결된 OOS 계좌 복리 시뮬레이션.
- 전략별 가상계좌·정확한 sleeve PnL 귀속, plugin sandbox, AI 연구 자동화/후보 DB.

요구서의 나머지 항목은 이 목록과 연결하여 단계별로 검증해야 한다. 빈 구현체로 완료 표시하지 않는다.
