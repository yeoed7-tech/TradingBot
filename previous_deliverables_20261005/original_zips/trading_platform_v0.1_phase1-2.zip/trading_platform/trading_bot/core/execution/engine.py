from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from trading_bot.core.events.models import Order, Fill, Side, Status, OrderType, TERMINAL
from trading_bot.core.risk.engine import floor_step


def tick_price(value,tick,up):
    return float((Decimal(str(value))/Decimal(str(tick))).to_integral_value(
        rounding=ROUND_CEILING if up else ROUND_FLOOR)*Decimal(str(tick)))

class ExecutionEngine:
    """Orders are independent from the fill backend. One active order per symbol."""
    def __init__(self,settings):
        self.settings=settings
        self.orders=[]
        self.ids=set()
        self.events=[]

    def submit(self,order):
        if order.id in self.ids: return False  # idempotent submission
        if any(o.symbol==order.symbol and o.status not in TERMINAL for o in self.orders):
            raise ValueError('active order already exists for symbol')
        order.transition(Status.SUBMITTED)
        self.orders.append(order)
        self.ids.add(order.id)
        return True

    def active(self,symbol):
        return next((o for o in self.orders if o.symbol==symbol and o.status not in TERMINAL),None)

    def cancel(self,order,reason='user_cancel'):
        if order.status not in TERMINAL: order.transition(Status.CANCELLED,reason)

    def propose(self,signal,portfolio,prices,risk,timestamp,index):
        if signal.symbol not in prices: raise ValueError('signal contains unknown symbol')
        if signal.target_weight is None: return
        symbol=signal.symbol
        rule=self.settings.rules_for(symbol)
        equity=portfolio.equity(prices)
        target=risk.target_weight(symbol,signal.target_weight,prices[symbol])
        desired=floor_step(equity*target/prices[symbol],rule.quantity_step)
        delta=desired-portfolio.quantity(symbol)
        current=self.active(symbol)
        side=Side.BUY if delta>0 else Side.SELL
        if current:
            if side!=current.side or abs(delta)*prices[symbol]<=equity*risk.config.rebalance_tolerance:
                self.cancel(current,'target_changed')
            else:
                return  # do not stack duplicate rebalances during latency
        if abs(delta)*prices[symbol]<=equity*risk.config.rebalance_tolerance and target!=0: return
        quantity=floor_step(abs(delta),rule.quantity_step)
        if quantity<=0 or quantity*prices[symbol]<rule.min_notional: return
        decision=risk.check(side)
        self.events.append({'timestamp':timestamp,'event':'risk_decision','symbol':symbol,
                            'allowed':decision.allowed,'reason':decision.reason})
        if not decision.allowed: return
        limit=signal.limit_price
        if limit is not None:
            limit=tick_price(limit,rule.price_tick,side==Side.SELL)
        order=Order(symbol,side,quantity,signal.strategy,timestamp,index+self.settings.execution.delay_bars,
                    signal.order_type,limit)
        self.submit(order)

class SimulationBroker:
    """Bar model, not an order-book/queue model. Deterministic partial fills.

    Uses prior completed bar volume to cap liquidity. Limit fills only when the
    next OPEN is marketable: avoids hidden intrabar path assumptions.
    """
    def __init__(self,settings):
        self.settings=settings

    def process(self,execution,index,bars,previous_volumes,portfolio,risk):
        prices={s:b.open for s,b in bars.items()}
        c=self.settings.execution
        used={}
        for order in execution.orders:
            if order.status in TERMINAL or index<order.eligible_bar: continue
            if risk.killed and order.side==Side.BUY:
                execution.cancel(order,'kill_switch'); continue
            if index>=order.eligible_bar+c.expiry_bars:
                execution.cancel(order,'expired'); continue
            b=bars[order.symbol]
            rule=self.settings.rules_for(order.symbol)
            buy=order.side==Side.BUY
            price=tick_price(b.open*(1+c.slippage_bps/10000*(1 if buy else -1)),rule.price_tick,buy)
            # No favorable hypothetical fill at an untouched limit.
            if order.order_type==OrderType.LIMIT:
                if (buy and price>order.limit_price) or (not buy and price<order.limit_price): continue
            slippage_bps=abs(price/b.open-1)*10000
            decision=risk.check(order.side,slippage_bps)
            if not decision.allowed:
                order.transition(Status.REJECTED,decision.reason); continue
            capacity=previous_volumes.get(order.symbol,0)*c.max_volume_participation-used.get(order.symbol,0)
            quantity=min(order.remaining,max(0.,capacity))
            if buy: quantity=min(quantity,risk.buy_capacity(order.symbol,portfolio,prices,price,c.fee_rate))
            else: quantity=min(quantity,portfolio.quantity(order.symbol))
            quantity=floor_step(quantity,rule.quantity_step)
            if quantity<=0:
                if capacity>0: execution.cancel(order,'cash_or_position_or_risk_capacity')
                continue
            if quantity*price<rule.min_notional:
                # A partial fill may be below min_notional, but an initial order may not.
                if order.filled==0 and order.remaining*price<rule.min_notional:
                    order.transition(Status.REJECTED,'min_notional'); continue
            fill=Fill(order.id,b.timestamp,order.symbol,order.strategy,order.side,quantity,price,
                      quantity*price*c.fee_rate,quantity*abs(price-b.open))
            portfolio.apply(fill,prices)
            used[order.symbol]=used.get(order.symbol,0)+quantity
            order.filled=float(Decimal(str(order.filled))+Decimal(str(quantity)))
            order.transition(Status.FILLED if order.remaining<rule.quantity_step/2 else Status.PARTIALLY_FILLED)
            risk.observe(b.timestamp,portfolio.equity(prices),portfolio.trades)
