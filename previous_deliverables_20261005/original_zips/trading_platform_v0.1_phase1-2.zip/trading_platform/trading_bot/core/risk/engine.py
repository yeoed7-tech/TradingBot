from dataclasses import dataclass
from collections import deque
from decimal import Decimal, ROUND_DOWN
import math
from trading_bot.core.events.models import Side


def floor_step(value,step):
    if value <= 0: return 0.
    return float((Decimal(str(value))/Decimal(str(step))).to_integral_value(rounding=ROUND_DOWN)*Decimal(str(step)))

@dataclass(frozen=True)
class Decision:
    allowed: bool
    reason: str

class RiskEngine:
    def __init__(self,config,initial_cash):
        self.config=config
        self.peak=initial_cash
        self.last_equity=initial_cash
        self.day=self.week=None
        self.day_start=self.week_start=initial_cash
        self.killed=False
        self.kill_reason=''
        self.consecutive_losses=0
        self.trades_seen=0
        self.tr={}
        self.previous_close={}
        self.events=[]

    def kill(self,reason):
        if not self.killed:
            self.killed=True
            self.kill_reason=reason
            self.events.append({'event':'kill_switch','reason':reason})

    def observe(self,timestamp,equity,trades):
        day=timestamp.date()
        week=timestamp.isocalendar()[:2]
        # Previous mark is the reference, so overnight gaps are counted.
        if day!=self.day: self.day,self.day_start=day,self.last_equity
        if week!=self.week: self.week,self.week_start=week,self.last_equity
        self.peak=max(self.peak,equity)
        for trade in trades[self.trades_seen:]:
            self.consecutive_losses=self.consecutive_losses+1 if trade['pnl']<0 else 0
        self.trades_seen=len(trades)
        c=self.config
        if equity <= 0: self.kill('nonpositive_equity')
        elif equity/self.peak-1 <= -c.max_drawdown: self.kill('max_drawdown')
        elif equity/self.day_start-1 <= -c.daily_loss: self.kill('daily_loss')
        elif equity/self.week_start-1 <= -c.weekly_loss: self.kill('weekly_loss')
        elif self.consecutive_losses >= c.max_consecutive_losses: self.kill('consecutive_losses')
        self.last_equity=equity

    def check_open(self,bars):
        for symbol,b in bars.items():
            prev=self.previous_close.get(symbol)
            if prev is not None and abs(b.open/prev-1)>self.config.max_price_jump:
                self.kill(f'abnormal_open:{symbol}')

    def observe_bars(self,bars):
        for symbol,b in bars.items():
            prev=self.previous_close.get(symbol,b.open)
            if abs(b.close/prev-1)>self.config.max_price_jump:
                self.kill(f'abnormal_close:{symbol}')
            tr=max(b.high-b.low,abs(b.high-prev),abs(b.low-prev))
            self.tr.setdefault(symbol,deque(maxlen=self.config.atr_period)).append(tr)
            self.previous_close[symbol]=b.close

    def target_weight(self,symbol,requested,price):
        c=self.config
        if c.sizing=='fixed_fractional':
            cap=c.fixed_fraction
        else:
            values=self.tr.get(symbol,())
            if len(values)<c.atr_period: return 0.
            atr=sum(values)/len(values)
            cap=0. if atr<=0 else c.risk_per_trade*price/(c.atr_multiple*atr)
        return max(0.,min(requested,cap,c.max_symbol_weight))

    def buy_capacity(self,symbol,portfolio,prices,fill_price,fee_rate):
        """Recheck at execution with all assets marked at currently known prices.

        Account for immediate fees in post-fill weight constraints.
        """
        equity=portfolio.equity(prices)
        c=self.config
        own=portfolio.quantity(symbol)*prices[symbol]
        gross=portfolio.gross(prices)
        delta=prices[symbol]-fill_price*(1+fee_rate)
        symbol_room=(c.max_symbol_weight*equity-own)/(prices[symbol]-c.max_symbol_weight*delta)
        gross_room=(c.max_gross_weight*equity-gross)/(prices[symbol]-c.max_gross_weight*delta)
        return max(0.,min(portfolio.cash/(fill_price*(1+fee_rate)),symbol_room,gross_room))

    def check(self,side,slippage_bps=0):
        if slippage_bps>self.config.max_slippage_bps:
            self.kill('excess_slippage')
        # Kill means no new exposure; risk-reducing exits are still permitted.
        if side==Side.BUY and self.killed: return Decision(False,self.kill_reason)
        return Decision(True,'reduce_exposure' if side==Side.SELL else 'approved')
