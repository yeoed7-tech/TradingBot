from dataclasses import dataclass
from datetime import datetime
import math
from decimal import Decimal
from trading_bot.core.events.models import Fill, Side

@dataclass
class Position:
    quantity: float = 0.0
    cost: float = 0.0  # remaining cost basis including entry fees
    opened_at: datetime | None = None
    realized: float = 0.0
    sold_quantity: float = 0.0

class Portfolio:
    def __init__(self,cash):
        if not math.isfinite(cash) or cash <= 0: raise ValueError('invalid starting cash')
        self.initial_cash = self.cash = float(cash)
        self.positions: dict[str,Position] = {}
        self.trades: list[dict] = []
        self.fills: list[dict] = []

    def quantity(self,symbol):
        return self.positions.get(symbol,Position()).quantity

    def equity(self,prices):
        return self.cash + sum(p.quantity*prices[s] for s,p in self.positions.items() if p.quantity > 0)

    def gross(self,prices):
        return sum(p.quantity*prices[s] for s,p in self.positions.items() if p.quantity > 0)

    def apply(self,fill: Fill,prices):
        if not all(math.isfinite(v) for v in (fill.quantity,fill.price,fill.fee)) or fill.quantity<=0 or fill.price<=0 or fill.fee<0:
            raise ValueError('invalid fill')
        p=self.positions.setdefault(fill.symbol,Position())
        value=fill.quantity*fill.price
        realized=0.
        if fill.side==Side.BUY:
            if value+fill.fee > self.cash+1e-8: raise ValueError('insufficient cash')
            if p.quantity==0: p.opened_at=fill.timestamp
            self.cash-=value+fill.fee
            p.quantity=float(Decimal(str(p.quantity))+Decimal(str(fill.quantity)))
            p.cost+=value+fill.fee
        else:
            if fill.quantity>p.quantity+1e-10: raise ValueError('cannot short spot holdings')
            cost=p.cost*(fill.quantity/p.quantity)
            realized=value-fill.fee-cost
            self.cash+=value-fill.fee
            p.quantity=max(0.,float(Decimal(str(p.quantity))-Decimal(str(fill.quantity))))
            p.cost=max(0.,p.cost-cost)
            p.realized+=realized
            p.sold_quantity+=fill.quantity
            if p.quantity < 1e-10:
                self.trades.append({'symbol':fill.symbol,'strategy':fill.strategy,'opened_at':p.opened_at,
                    'closed_at':fill.timestamp,'pnl':p.realized,'quantity':p.sold_quantity,
                    'holding_seconds':(fill.timestamp-p.opened_at).total_seconds()})
                self.positions[fill.symbol]=Position()
        self.fills.append({**fill.__dict__,'signal':fill.side.value,'portfolio_value':self.equity(prices),'pnl':realized})
        return realized
