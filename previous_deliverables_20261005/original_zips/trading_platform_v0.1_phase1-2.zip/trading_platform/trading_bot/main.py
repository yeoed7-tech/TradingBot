import argparse
import hashlib
import json
from pathlib import Path
import pandas as pd
from trading_bot.config.settings import Settings
from trading_bot.data.market_data import synthetic_data,MarketDataEngine
from trading_bot.strategies import create_strategy
from trading_bot.backtest.engine import BacktestEngine
from trading_bot.backtest.validation import walk_forward,grid_search,chronological_split
from trading_bot.analytics.report import write_report,compare


def main(argv=None):
    parser=argparse.ArgumentParser(description='Offline crypto strategy research platform (Phase 1–2)')
    parser.add_argument('command',choices=['demo','backtest','compare','optimize','walk-forward','split','paper','live'])
    parser.add_argument('--config',default='config/default.toml')
    parser.add_argument('--data',help='CSV OHLCV; mandatory except demo')
    parser.add_argument('--out',default='reports/run')
    parser.add_argument('--grid',default='config/grid.json')
    parser.add_argument('--train-bars',type=int,default=300)
    parser.add_argument('--test-bars',type=int,default=100)
    parser.add_argument('--train-end',default='2023-01-01')
    parser.add_argument('--test-end',default='2024-01-01')
    args=parser.parse_args(argv)
    if args.command in {'paper','live'}:
        parser.error(f'{args.command} is not implemented in Phase 1–2; no exchange order can be submitted')
    settings=Settings.load(args.config)
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    if args.command=='demo':
        frame=synthetic_data()
        frame.to_csv(out/'synthetic_ohlcv.csv',index=False)
        source='SYNTHETIC deterministic fixture (seed=42), NOT actual crypto history'
    else:
        if not args.data: parser.error('--data is required')
        frame=MarketDataEngine.from_csv(args.data,settings.bar_seconds).frame
        source='User CSV SHA256='+hashlib.sha256(Path(args.data).read_bytes()).hexdigest()
    if args.command in {'demo','compare'}:
        results={name:BacktestEngine(settings).run(frame,create_strategy(name),name) for name in ['ema_cross','rsi','breakout']}
        print(compare(results,out,source).to_string())
    elif args.command=='backtest':
        result=BacktestEngine(settings).run(frame,create_strategy(settings.strategy.name,settings.strategy.params),settings.strategy.name)
        print(json.dumps(write_report(result,out,source),indent=2))
    elif args.command=='split':
        parts=chronological_split(frame,args.train_end,args.test_end)
        for name,part in parts.items(): part.to_csv(out/f'{name}.csv',index=False)
        print({k:len(v) for k,v in parts.items()})
    else:
        grid=json.loads(Path(args.grid).read_text())
        if args.command=='optimize':
            result=grid_search(frame,settings,settings.strategy.name,grid,settings.strategy.params)
        else:
            result=walk_forward(frame,settings,settings.strategy.name,grid,args.train_bars,args.test_bars,settings.strategy.params)
        (out/'validation.json').write_text(json.dumps(result,indent=2,allow_nan=False),encoding='utf-8')
        print(json.dumps(result,indent=2))
    print(f'Output: {out.resolve()}')

if __name__=='__main__': main()
