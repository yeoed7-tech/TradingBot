from pathlib import Path
import tomllib
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator

class StrictModel(BaseModel):
    model_config = ConfigDict(extra='forbid', allow_inf_nan=False)

class MarketRules(StrictModel):
    min_notional: float = Field(default=10, ge=0)
    price_tick: float = Field(default=0.01, gt=0)
    quantity_step: float = Field(default=0.000001, gt=0)

class ExecutionConfig(StrictModel):
    fee_rate: float = Field(default=0.001, ge=0, lt=0.1)
    slippage_bps: float = Field(default=5, ge=0, lt=10000)
    delay_bars: int = Field(default=1, ge=1)
    max_volume_participation: float = Field(default=0.01, gt=0, le=1)
    expiry_bars: int = Field(default=4, ge=1)

class RiskConfig(StrictModel):
    max_gross_weight: float = Field(default=0.8, gt=0, le=1)
    max_symbol_weight: float = Field(default=0.5, gt=0, le=1)
    daily_loss: float = Field(default=0.03, gt=0, le=1)
    weekly_loss: float = Field(default=0.08, gt=0, le=1)
    max_drawdown: float = Field(default=0.2, gt=0, le=1)
    max_consecutive_losses: int = Field(default=5, ge=1)
    max_price_jump: float = Field(default=0.5, gt=0)
    max_slippage_bps: float = Field(default=50, ge=0)
    sizing: Literal['fixed_fractional','atr'] = 'fixed_fractional'
    fixed_fraction: float = Field(default=0.02, gt=0, le=1)
    risk_per_trade: float = Field(default=0.01, gt=0, le=1)
    atr_multiple: float = Field(default=2, gt=0)
    atr_period: int = Field(default=14, ge=2)
    rebalance_tolerance: float = Field(default=0.005, ge=0, lt=1)

class StrategyConfig(StrictModel):
    name: str = 'ema_cross'
    params: dict = Field(default_factory=dict)

class Settings(StrictModel):
    initial_cash: float = Field(default=100000, gt=0)
    bar_seconds: int = Field(default=86400, ge=1)
    live_trading: Literal[False] = False
    strategy: StrategyConfig = Field(default_factory=StrategyConfig)
    execution: ExecutionConfig = Field(default_factory=ExecutionConfig)
    risk: RiskConfig = Field(default_factory=RiskConfig)
    rules: MarketRules = Field(default_factory=MarketRules)
    symbol_rules: dict[str, MarketRules] = Field(default_factory=dict)

    def rules_for(self, symbol):
        return self.symbol_rules.get(symbol, self.rules)

    @model_validator(mode='after')
    def validate_execution(self):
        if self.execution.slippage_bps > self.risk.max_slippage_bps:
            raise ValueError('configured slippage exceeds kill-switch threshold')
        return self

    @classmethod
    def load(cls, path):
        with Path(path).open('rb') as f:
            return cls.model_validate(tomllib.load(f))
