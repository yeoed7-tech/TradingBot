# Upbit Phase 3 공개 연결 진단

검증: 2026-09-28 한국시간 10:05–10:07, 실제 Work 실행환경.

**결론: 공개 REST/WebSocket 접근 및 실제 원문 시세 수신 성공.**
원인 분류: **CLIENT_PROXY_AND_CA_CONFIGURATION_MISMATCH**.
전체 환경을 `ENVIRONMENT_NETWORK_LIMITATION`으로 분류하지 않는다.

## 최소 테스트 결과

| 단계 | 결과 | 증거 |
|---|---|---|
| 시스템 DNS getaddrinfo(api.upbit.com) | 실패 | gaierror -3, Temporary failure in name resolution |
| 환경 프록시 경유 TLS | 성공 | TLSv1.3, 검증 활성, CONNECT tunnel 사용 |
| HTTPS GET /v1 | HTTP 404 | JSON not_found; 루트 리소스 없음, TLS 연결 실패가 아님 |
| GET /v1/ticker?markets=KRW-BTC | **HTTP 200** | KRW-BTC JSON 원문 833 bytes |
| wss://api.upbit.com/websocket/v1 handshake | **HTTP 101** | 업그레이드 성공 |
| ticker 단일 구독 | 성공 | codes=[KRW-BTC], 인증정보 없음 |
| ticker 원문 수신 | **성공** | 988 bytes, type=ticker, code=KRW-BTC, stream_type=SNAPSHOT |
| WebSocket 정상 종료 | 성공 | close code **1000** |

시스템 DNS 실패와 프록시를 통한 정상 연결은 동시에 가능하다. 목적지 이름 해석/연결을 프록시가 처리한다.
TLS 메타데이터는 환경의 신뢰된 프록시와 맺은 TLS 세션을 나타낸다.
직접 업비트 인증서를 관찰했다거나 프록시 내부의 upstream TLS를 독립 검증했다고 주장하지 않는다.

검증당 실제 시도 1회, 재시도 0회. 로컬 스크립트 기본값은 최대 2회이며 각 로그의 attempt/retry_count로 구분한다.
수신 가격은 연결 검증 자료이며 투자 분석에 사용하지 않았다.

## 기존 CCXT 오류 분리 재현

같은 ccxt 4.5.84, 동일한 Public GET, API Key 없이 실행했다.

| 클라이언트 설정 | 결과 | 최하위 원인 |
|---|---|---|
| 기존과 같은 기본 설정 | 실패 | ExchangeNotAvailable → ClientConnectorDNSError → gaierror |
| aiohttp_trust_env=True만 추가 | 실패 | ExchangeNotAvailable → ClientConnectorCertificateError → SSLCertVerificationError |
| 환경 프록시 + 시스템 SSLContext | **성공** | market/all과 KRW-BTC ticker 완료, 원문 저장 |

CCXT 설치 소스를 확인한 결과 기본 `aiohttp_trust_env=False`이다.
기본 SSLContext는 CCXT의 CA bundle을 사용한다. 이번 환경의 신뢰된 프록시 인증서를 포함한 시스템
SSLContext를 적용하면 검증을 끄지 않고 정상 연결된다.

따라서:
- 환경 측 특성: 직접 이름 해석 실패, 환경 프록시와 신뢰 CA가 제공됨.
- 클라이언트 설정 문제: 기존 생성 코드가 환경 프록시와 시스템 신뢰 CA를 반영하지 않음.
- 매매 애플리케이션 로직: 이번 최소 테스트는 Strategy/Risk/Portfolio/SimulationBroker를 전혀 import하지 않음.
  해당 로직이 최초 네트워크 실패의 원인이라는 증거가 없고, 네트워크 실패는 독립적으로 재현됨.
- 공개 API 차단/업비트 장애/API Key 누락: 이번 성공 결과로는 해당 원인으로 볼 수 없음.

## 검증된 연결 설정

```python
import ssl
import ccxt.async_support as ccxt

client = ccxt.upbit({
    "enableRateLimit": True,
    "timeout": 15000,
    "aiohttp_trust_env": True,
    "ssl_context": ssl.create_default_context(),
})
```

기존 프로젝트에 반영할 위치는 GuardedUpbit의 부모 클래스 초기화 설정이다.
공개 GET/path/host 제한은 그대로 유지해야 한다. 인증서 검증을 끄거나 프록시를 우회하지 않는다.
이번 납품은 독립 진단 패키지다. 기존 프로젝트 ZIP을 수정하거나 Phase 3 전체를 완료 처리하지 않았다.

## 증거 파일

- `work_results/events.jsonl`: DNS/TLS/HTTP/WS 단계, 상태, 예외, 본문, 재시도 횟수.
- `work_results/rest_ticker_1.bin`: REST 실제 raw bytes.
- `work_results/ws_payload_1.bin`: WebSocket 실제 raw bytes.
- `work_results/summary.json`: PUBLIC_CONNECTIVITY_OK, Phase 3 PARTIAL 유지.
- `ccxt_results/events.jsonl`: 세 CCXT 설정의 예외 체인 및 성공 결과.
- `ccxt_results/env_proxy_os_ca_ticker.bin`: CCXT 성공 응답 원문.

DNS/TLS 단계에서 HTTP 응답이 없으면 HTTP status/body는 null이다.
WS handshake 전에 실패하면 WebSocket close code는 null이며, 가짜 close code를 기록하지 않는다.
별도 로그 처리 테스트 8개 통과: HTTP handshake 오류 본문/상태, WS close code, DNS cause 보존,
403의 과도한 환경 제한 판정 방지, 프록시 사용자정보 마스킹 등.

## 남은 검증

최소 연결 성공은 전체 Phase 3 E2E 완료와 다르다.
연결 설정을 기존 공개 전용 adapter에 반영한 뒤 OHLCV/호가→전략→리스크→가상 체결→PnL을
실제 시세로 다시 검증해야 한다. 이번 WS 검증은 단일 ticker snapshot 수신까지이며 장시간 streaming/reconnect 검증이 아니다.
실제 주문 요청은 0건이다. Phase 3 상태는 계속 PARTIAL이다.
