import unittest
import socket
from websockets.exceptions import InvalidStatus,ConnectionClosedError
from websockets.http11 import Response
from websockets.datastructures import Headers
from websockets.frames import Close
from check_upbit import classification,exception_fields,redact

class DiagnosticsTests(unittest.TestCase):
    def test_plain_403_does_not_claim_environment_policy(self):
        self.assertEqual(classification([{'stage':'rest_ticker','ok':False,'http_status':403,'response_body':'Forbidden'}]),'CONNECTIVITY_FAILURE_UNATTRIBUTED')
    def test_explicit_policy_block(self):
        self.assertEqual(classification([{'stage':'rest_ticker','ok':False,'response_body':'domain is not allowed'}]),'ENVIRONMENT_NETWORK_LIMITATION')
    def test_rest_success_ws_failure_is_partial(self):
        self.assertEqual(classification([{'stage':'rest_ticker','ok':True},{'stage':'ws_handshake','ok':False}]),'PARTIAL_CONNECTIVITY')
    def test_both_public_transports_success(self):
        self.assertEqual(classification([{'stage':'dns','ok':False},{'stage':'rest_ticker','ok':True},{'stage':'ws_payload','ok':True}]),'PUBLIC_CONNECTIVITY_OK')
    def test_handshake_failure_status_and_body(self):
        r=Response(403,'Forbidden',Headers(),b'domain is not allowed')
        fields=exception_fields(InvalidStatus(r))
        self.assertEqual(fields['http_status'],403)
        self.assertEqual(fields['response_body'],'domain is not allowed')
        self.assertIsNone(fields['websocket_close_code']) # no socket established
    def test_received_close_code(self):
        fields=exception_fields(ConnectionClosedError(Close(1008,'policy'),None,None))
        self.assertEqual(fields['websocket_close_code'],1008)
    def test_dns_cause_not_discarded(self):
        try:
            try:raise socket.gaierror(-3,'name resolution')
            except Exception as e:raise RuntimeError('outer') from e
        except Exception as e:fields=exception_fields(e)
        self.assertEqual([x['type'] for x in fields['exception_chain']],['RuntimeError','gaierror'])
    def test_proxy_credentials_redacted(self):
        self.assertEqual(redact('https://user:password@proxy:443'), 'https://[REDACTED]@proxy:443')

if __name__=='__main__':unittest.main()
