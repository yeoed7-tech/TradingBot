# 로컬 공개 연결 검증

이 패키지는 기존 거래 플랫폼 없이 실행하는 독립 진단 도구입니다.
API Key, 로그인, 계좌 접근이 필요하지 않습니다. 공개 조회·ticker 구독만 수행합니다.

Python 3.12 이상에서 압축을 풀고 다음을 실행하세요.

```bash
cd upbit_connection_diagnostics
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux에서는 위 줄 대신:
# source .venv/bin/activate
python -m pip install -r requirements.txt
python check_upbit.py --out local_results --attempts 2 --timeout 15
```

정상일 때 DNS(로컬 환경에 따라 다름), 프록시/기본경로 TLS, HTTP 200 ticker,
HTTP 101 WebSocket handshake, ticker raw payload, 정상 close=1000을 기록합니다.
`/v1` 자체의 HTTP 404는 루트 경로에 서비스가 없다는 의미이며 TLS 실패가 아닙니다.

프록시·CA 환경과 CCXT 기본값을 비교하려면:

```bash
python check_ccxt_proxy.py --out local_ccxt_results --profile all --timeout 15
```

`default`는 기존 CCXT 설정 재현, `env_proxy`는 환경 프록시 반영,
`env_proxy_os_ca`는 환경 프록시와 시스템 신뢰 인증서 반영입니다.
특정 설정만 실행하려면 `--profile env_proxy_os_ca`처럼 지정합니다.
시스템 proxy/CA 설정을 출력하거나 변경하지 않으며 TLS 검증을 비활성화하지 않습니다.

파일:
- `check_upbit.py`: DNS/TLS/REST/WS 최소 진단, 표준 라이브러리 + websockets.
- `check_ccxt_proxy.py`: CCXT 설정 비교. 공개 GET 두 경로만 허용.
- `DIAGNOSIS.md`: Work에서 실제 실행한 결과와 원인.
- `work_results/`, `ccxt_results/`: 실제 응답 원문 및 JSONL 로그.
- `test_diagnostics.py`: 로그와 오류 분류 테스트.

```bash
python -m unittest -v test_diagnostics
```

로그의 exception_type, exception_chain, http_status, websocket_close_code, response_body,
attempt, retry_count를 확인하세요. 수신 원문은 .bin 파일과 로그의 base64에도 보관합니다.
응답이 존재하지 않는 값은 null, handshake 실패 후 구독/수신은 skipped로 기록합니다.
REST 응답은 64 KiB를 상한으로 두며 잘렸다면 body_truncated=true로 표시합니다.

분류:
- PUBLIC_CONNECTIVITY_OK: REST 및 WS ticker payload 검증 성공. Phase 3 전체 완료를 뜻하지 않음.
- PARTIAL_CONNECTIVITY: 두 경로 중 하나만 성공.
- ENVIRONMENT_NETWORK_LIMITATION: 명시적인 네트워크 정책 차단 응답을 확인한 경우.
- CONNECTIVITY_FAILURE_UNATTRIBUTED: 원인을 아직 확정할 수 없는 실패.

403 또는 timeout 하나만으로 환경 차단/코드 결함을 단정하지 않습니다.
현재 Work 결과는 **PUBLIC_CONNECTIVITY_OK**이며, 기존 실패는 **프록시·CA 설정 미반영**으로 재현했습니다.

공식 스키마 참고:
https://docs.upbit.com/kr/reference/websocket-ticker
https://docs.upbit.com/kr/kr/reference/websocket-guide
https://websockets.readthedocs.io/en/16.0/reference/exceptions.html
