"""Independent public-only probe. Python 3.12+, websockets 16.0. No bot imports.
Honors system proxy/CA settings. Never disables TLS verification or changes routes.
"""
import argparse
import asyncio
import base64
import http.client
import json
import os
from pathlib import Path
import re
import socket
import ssl
import time
from datetime import datetime,timezone
from urllib import request,error
from uuid import uuid4
from websockets.asyncio.client import connect

HOST='api.upbit.com'
BASE='https://api.upbit.com/v1'
REST=BASE+'/ticker?markets=KRW-BTC'
WS='wss://api.upbit.com/websocket/v1'


def redact(text):
    return re.sub(r'(https?://|socks\w*://)[^/\s@]+@',r'\1[REDACTED]@',str(text))


def exception_fields(exc):
    chain=[]; seen=set(); current=exc
    while current is not None and id(current) not in seen:
        seen.add(id(current));chain.append({'type':type(current).__name__,'message':redact(current)})
        current=current.__cause__ or current.__context__
    response=getattr(exc,'response',None)
    received=getattr(exc,'rcvd',None)
    return {'exception_type':type(exc).__name__,'exception':redact(exc),'exception_chain':chain,
            'http_status':getattr(response,'status_code',None),
            'websocket_close_code':getattr(received,'code',None),
            'websocket_close_reason':getattr(received,'reason',None),
            'response_body':bytes(getattr(response,'body',b'') or b'').decode('utf-8','replace') if response else None}

class Journal:
    def __init__(self,out):
        self.out=Path(out);self.out.mkdir(parents=True,exist_ok=True);self.events=[]
        (self.out/'events.jsonl').write_text('')
    def log(self,stage,attempt,ok,**data):
        row={'timestamp':datetime.now(timezone.utc).isoformat(),'stage':stage,'attempt':attempt,
             'retry_count':max(0,attempt-1),'ok':ok,'exception_type':None,'http_status':None,
             'websocket_close_code':None,'response_body':None,**data}
        self.events.append(row)
        with (self.out/'events.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
        print(json.dumps(row,ensure_ascii=False),flush=True)
    def raw(self,name,payload):
        data=payload.encode('utf-8') if isinstance(payload,str) else bytes(payload)
        (self.out/name).write_bytes(data)
        return {'raw_file':name,'raw_bytes':len(data),'raw_base64':base64.b64encode(data).decode(),
                'response_body':data.decode('utf-8','replace')}


def http_probe(url,timeout):
    """Use urllib's normal ProxyHandler; instrument TLS without bypassing it."""
    tls={}
    class Connection(http.client.HTTPSConnection):
        def connect(self):
            super().connect()
            tls.update({'verified':True,'version':self.sock.version(),'cipher':self.sock.cipher()[0],
                        'certificate_issuer':self.sock.getpeercert().get('issuer'),
                        'tunnel_used':bool(self._tunnel_host)})
    class Handler(request.HTTPSHandler):
        def https_open(self,req):
            return self.do_open(Connection,req,context=ssl.create_default_context())
    opener=request.build_opener(Handler())
    req=request.Request(url,headers={'User-Agent':'PublicConnectivityProbe/1.0','Accept':'application/json'})
    try:
        with opener.open(req,timeout=timeout) as r:
            body=r.read(65537)
            return r.status,dict(r.headers),body[:65536],len(body)>65536,tls,None
    except error.HTTPError as exc:
        body=exc.read(65537)
        return exc.code,dict(exc.headers),body[:65536],len(body)>65536,tls,exc
    except Exception as exc:
        return None,{},b'',False,tls,exc


def policy_denial(events):
    # Do not equate arbitrary 403/timeout with Work policy enforcement.
    phrases=('domain is not allowed','domain not allowed','not in the allowed','blocked by policy',
             'network access is disabled','egress policy','proxy policy','network policy',
             'request denied by','blocked: domain','blocked by the proxy','robots_denied')
    for e in events:
        body=(e.get('response_body') or '').lower()
        if any(p in body for p in phrases):return True
        headers=e.get('response_headers',{})
        if any(k.lower()=='x-mitmproxy-blocked-reason' for k in headers):return True
    return False


def classification(events):
    rest=any(e['stage']=='rest_ticker' and e['ok'] for e in events)
    ws=any(e['stage']=='ws_payload' and e['ok'] for e in events)
    if rest and ws:return 'PUBLIC_CONNECTIVITY_OK'
    if policy_denial(events):return 'ENVIRONMENT_NETWORK_LIMITATION'
    if rest or ws:return 'PARTIAL_CONNECTIVITY'
    return 'CONNECTIVITY_FAILURE_UNATTRIBUTED'

async def run(args):
    log=Journal(args.out)
    log.log('environment',0,True,python=os.sys.version,proxy_configured=bool(request.getproxies()),
            tls_verification=True,credentials_used=False,application_logic_loaded=False)
    loop=asyncio.get_running_loop()
    for attempt in range(1,args.attempts+1):
        try:
            addresses=await asyncio.wait_for(loop.getaddrinfo(HOST,443,type=socket.SOCK_STREAM),args.timeout)
            log.log('dns',attempt,True,host=HOST,addresses=sorted({x[4][0] for x in addresses}),
                    note='system resolver; proxy may resolve independently')
            break
        except Exception as exc:log.log('dns',attempt,False,**exception_fields(exc))
        if attempt<args.attempts:await asyncio.sleep(min(2**(attempt-1),4))
    for stage,url in [('base_https',BASE),('rest_ticker',REST)]:
        for attempt in range(1,args.attempts+1):
            start=time.monotonic()
            status,headers,body,truncated,tls,exc=await asyncio.to_thread(http_probe,url,args.timeout)
            fields=exception_fields(exc) if exc else {}
            ok=False
            if stage=='base_https':ok=bool(tls) # /v1 itself may legitimately return 404
            elif status==200:
                try:
                    payload=json.loads(body)
                    ok=isinstance(payload,list) and bool(payload) and payload[0].get('market')=='KRW-BTC' and payload[0].get('trade_price',0)>0
                except (ValueError,TypeError,AttributeError):pass
            log.log(stage,attempt,ok,**{**fields,'http_status':status,'response_headers':{k:v for k,v in headers.items() if k.lower() not in {'set-cookie','proxy-authenticate'}},
                    **log.raw(f'{stage}_{attempt}.bin',body),'body_truncated':truncated,'tls':tls,
                    'elapsed_seconds':round(time.monotonic()-start,3),'url':url})
            if ok:break
            if attempt<args.attempts:await asyncio.sleep(min(2**(attempt-1),4))
    for attempt in range(1,args.attempts+1):
        opened=False;socket_ws=None
        try:
            async with connect(WS,open_timeout=args.timeout,close_timeout=3,ping_interval=20,
                               ping_timeout=10,max_size=1048576) as socket_ws:
                opened=True
                log.log('ws_handshake',attempt,True,http_status=socket_ws.response.status_code,url=WS)
                subscription=[{'ticket':str(uuid4())},{'type':'ticker','codes':['KRW-BTC']},{'format':'DEFAULT'}]
                await socket_ws.send(json.dumps(subscription))
                log.log('ws_subscription',attempt,True,request=subscription)
                payload=await asyncio.wait_for(socket_ws.recv(),args.timeout)
                raw=log.raw(f'ws_payload_{attempt}.bin',payload)
                try:
                    obj=json.loads(payload)
                    ok=isinstance(obj,dict) and obj.get('type')=='ticker' and obj.get('code')=='KRW-BTC' and obj.get('trade_price',0)>0
                except (ValueError,TypeError):ok=False
                log.log('ws_payload',attempt,ok,**raw)
            log.log('ws_close',attempt,True,websocket_close_code=socket_ws.close_code,websocket_close_reason=socket_ws.close_reason)
            if ok:break
        except Exception as exc:
            data=exception_fields(exc)
            response=getattr(exc,'response',None)
            if response is not None:
                data['response_headers']={k:v for k,v in response.headers.raw_items() if k.lower() not in {'set-cookie','proxy-authenticate'}}
                data.update(log.raw(f'ws_handshake_error_{attempt}.bin',bytes(response.body or b'')))
            log.log('ws_receive' if opened else 'ws_handshake',attempt,False,**data)
            if not opened:
                log.log('ws_subscription',attempt,False,skipped=True,reason='handshake failed; no subscription sent')
                log.log('ws_payload',attempt,False,skipped=True,reason='no established WebSocket; no ticker payload')
        if attempt<args.attempts:await asyncio.sleep(min(2**(attempt-1),4))
    summary={'classification':classification(log.events),'phase3_status':'PARTIAL',
             'phase3_completion_asserted':False,'attempt_limit_per_stage':args.attempts,
             'rest_success':any(e['stage']=='rest_ticker' and e['ok'] for e in log.events),
             'websocket_ticker_success':any(e['stage']=='ws_payload' and e['ok'] for e in log.events),
             'application_logic_loaded':False,'real_order_requests':0,
             'note':'Connectivity alone does not prove Phase 3 strategy/risk/fill E2E completion.'}
    (log.out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))
    return 0 if summary['classification']=='PUBLIC_CONNECTIVITY_OK' else 2

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',default='diagnostic_results')
    p.add_argument('--attempts',type=int,default=2,choices=range(1,4))
    p.add_argument('--timeout',type=float,default=10)
    args=p.parse_args()
    if not 0<args.timeout<=60:p.error('--timeout must be in (0,60]')
    raise SystemExit(asyncio.run(run(args)))

if __name__=='__main__':main()
