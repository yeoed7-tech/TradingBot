"""Reproduce CCXT defaults and compare approved environment proxy/CA settings.
No credentials, no bot logic, only two public GET endpoints.
"""
import argparse
import asyncio
import json
import ssl
from pathlib import Path
import ccxt.async_support as ccxt
from check_upbit import Journal,exception_fields

class PublicProbe(ccxt.upbit):
    def sign(self,path,api='public',method='GET',params=None,headers=None,body=None):
        if api!='public' or method!='GET' or path not in {'market/all','ticker'}:
            raise RuntimeError('probe allows public market/all and ticker GET only')
        return super().sign(path,api,method,params or {},headers,body)

async def run(args):
    log=Journal(args.out)
    profiles=['default','env_proxy','env_proxy_os_ca'] if args.profile=='all' else [args.profile]
    for profile in profiles:
        config={'enableRateLimit':True,'timeout':args.timeout*1000}
        if profile!='default':config['aiohttp_trust_env']=True
        if profile=='env_proxy_os_ca':config['ssl_context']=ssl.create_default_context()
        client=PublicProbe(config)
        try:
            ticker=await client.fetch_ticker('BTC/KRW')
            raw=client.last_http_response or ''
            data=log.raw(profile+'_ticker.bin',raw)
            log.log('ccxt_'+profile,1,True,ccxt_version=ccxt.__version__,
                    aiohttp_trust_env=client.aiohttp_trust_env,verify=client.verify,
                    last=ticker['last'],exchange_timestamp=ticker['timestamp'],**data)
        except Exception as exc:
            data=exception_fields(exc)
            if client.last_http_response:data.update(log.raw(profile+'_error.bin',client.last_http_response))
            log.log('ccxt_'+profile,1,False,ccxt_version=ccxt.__version__,
                    aiohttp_trust_env=client.aiohttp_trust_env,verify=client.verify,**data)
        finally:await client.close()
    (Path(args.out)/'summary.json').write_text(json.dumps(log.events,indent=2),encoding='utf-8')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',default='ccxt_results')
    p.add_argument('--profile',choices=['all','default','env_proxy','env_proxy_os_ca'],default='all')
    p.add_argument('--timeout',type=int,default=15)
    a=p.parse_args()
    asyncio.run(run(a))
